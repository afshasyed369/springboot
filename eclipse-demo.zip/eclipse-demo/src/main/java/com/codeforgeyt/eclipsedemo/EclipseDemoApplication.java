package com.codeforgeyt.eclipsedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EclipseDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EclipseDemoApplication.class, args);
		System.out.println("Hello World!");
	}

}
